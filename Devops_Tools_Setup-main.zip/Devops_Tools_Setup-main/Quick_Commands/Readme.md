## Jenkins
      yum install git -y && git clone https://github.com/iamkishore0/Devops_Tools_Setup.git && cd Devops_Tools_Setup && cd Jenkins && chmod +x Jenkins_installation_centos_rhel.sh && ./Jenkins_installation_centos_rhel.sh

## Nexus
      yum install git -y && git clone https://github.com/iamkishore0/Devops_Tools_Setup.git && cd Devops_Tools_Setup && cd Nexus && chmod +x nexus_centos.sh && ./nexus_centos.sh
      
## Tomcat
      yum install git -y && git clone https://github.com/iamkishore0/Devops_Tools_Setup.git && cd Devops_Tools_Setup && cd Apache_Tomcat && chmod +x centos_rhel_vm.sh && ./centos_rhel_vm.sh
