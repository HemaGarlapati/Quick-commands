Install Docker in RHEL/Centos 
  Give execution permissions to Docker_installation_centos_rhel.sh file "chmod +x Docker_installation_centos_rhel.sh"
  Execute script file "./Docker_installation_centos_rhel.sh"
  
 
Install Docker in Debian/Ubuntu
  Give execution permissions to Docker_installation_debain_ubuntu.sh file "chmod +x Docker_installation_debain_ubuntu.sh"
  Execute script file "./Docker_installation_debain_ubuntu.sh"
 
