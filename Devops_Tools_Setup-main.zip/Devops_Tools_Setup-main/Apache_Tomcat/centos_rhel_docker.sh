sudo docker build -t mytomcat . &&
sudo docker compose up -d
