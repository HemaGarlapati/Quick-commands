System requirements 
  Memory: 4GB 
  VCPU: 2 (Recomended 4)
  Volume: 64GB 

Run Nexus in Docker container
  Pre-requisites: Docker & Docker-compose
  Install Docker & Docker-compose using the below link in Centos/RHEL/Debain/Ubuntu
  https://github.com/devopslife999/Setup_Quick_Access/tree/main/Docker
  
  For Centos/RHEL linux execute "sudo docker compose up -d" to run Nexus in docker container
  For Debain/Ubuntu linux execute "sudo docker-compose up -d" to run Nexus in docker container
  Access Nexus server at 8081 port "localhost:8081 or <publicip>:8081"

Nexus login details
username: admin
password: admin123
